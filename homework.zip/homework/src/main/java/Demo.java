import domain.Student;
import server.SelectInfo;
import server.UpdateInfo;

import java.util.List;

/**
 * @author nmtl_ygw
 * @Description
 * @date 2020/6/18 9:34
 */
public class Demo {
    public static void main(String[] args) {
        SelectInfo selectInfo = new SelectInfo();
        UpdateInfo updateInfo = new UpdateInfo();
        //查找全部
        List<Student> all = selectInfo.findAll();
        System.out.println("查找全部："+all.get(0));
        //根据id查找
        Student byId = selectInfo.findById(2017202001);
        System.out.println("根据id查找"+byId);
        //插入数据
        Integer integer = updateInfo.insertInfo(2017202005, "袁国伟", 21, 0, "软件17-1", "内蒙古呼和浩特");
        System.out.println("影响条数:" + integer);

        //根据id删除
        Integer delete = updateInfo.delete("2017202002");
        System.out.println("影响条数:" + delete);
    }

}
