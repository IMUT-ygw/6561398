package utils;

import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.Properties;

/**
 * @author nmtl_ygw
 * @Description jdbc工具类
 * @date 2020/6/18 8:23
 */
public class JdbcUtils {
    public static Connection getConnection(){
        //读取配置文件的数据源信息
        InputStream resourceAsStream = ClassLoader.getSystemClassLoader().getResourceAsStream("jdbc.properties");
        Properties properties = new Properties();
        //加载文件
        try {
            properties.load(resourceAsStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
        //获取值
        String driverClass = properties.getProperty("driverClass");
        String url = properties.getProperty("url");
        String user = properties.getProperty("user");
        String password = properties.getProperty("password");
        Connection connection = null;
        //加载驱动
        try {
            Class.forName(driverClass);
            connection = DriverManager.getConnection(url, user, password);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return connection;
    }

    //关闭资源
    public static void closeResourceResult(Connection connection, Statement statement, ResultSet resultSet){
        try {
            if (statement != null) {
                statement.close();
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        try{
            if(connection != null){
                connection.close();
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        try{
            if(resultSet != null){
                resultSet.close();
            }
        }catch (SQLException e){
            e.printStackTrace();
        }

    }
}
